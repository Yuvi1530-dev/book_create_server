var appData = {
    "status" : 1,
    "message" : "",
    "data" : [],
    "error" : []
}
